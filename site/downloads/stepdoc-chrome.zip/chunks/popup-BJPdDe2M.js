import"./browser-SltQ4TBi.js";import"./capture-panel-Dk6tqEKK.js";import"./preferences-CcbNpR_D.js";try{}catch(i){console.error("[wxt] Failed to initialize plugins",i)}
